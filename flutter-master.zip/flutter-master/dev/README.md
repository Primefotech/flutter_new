This directory contains tools and resources that the Flutter team uses
during the development of the framework. The tools in this directory
should not be necessary for developing Flutter applications, though of
course, they may be interesting if you are curious.

The tests in this directory are run in the `framework_tests_misc-*`
shards.
