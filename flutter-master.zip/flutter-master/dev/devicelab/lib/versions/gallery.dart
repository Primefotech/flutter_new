// Copyright 2014 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

/// The pinned version of flutter gallery, used for devicelab tests.
const String galleryVersion = '221023a99dc7d4e1a6b1bd3d53e5d9551b785774';
